/**
 * Spring Data JPA repositories.
 */
package com.projectweb3.repository;
