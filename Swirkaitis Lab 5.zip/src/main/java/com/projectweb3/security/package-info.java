/**
 * Spring Security configuration.
 */
package com.projectweb3.security;
