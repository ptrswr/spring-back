/**
 * JPA domain objects.
 */
package com.projectweb3.domain;
