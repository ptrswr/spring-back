/**
 * Data Transfer Objects.
 */
package com.projectweb3.service.dto;
