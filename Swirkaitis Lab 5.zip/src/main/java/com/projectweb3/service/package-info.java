/**
 * Service layer beans.
 */
package com.projectweb3.service;
