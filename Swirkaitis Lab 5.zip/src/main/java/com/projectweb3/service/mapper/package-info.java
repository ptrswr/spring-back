/**
 * MapStruct mappers for mapping domain objects and Data Transfer Objects.
 */
package com.projectweb3.service.mapper;
