/**
 * View Models used by Spring MVC REST controllers.
 */
package com.projectweb3.web.rest.vm;
