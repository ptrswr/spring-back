import axios, { AxiosInstance, AxiosPromise } from 'axios';

export default class MetricsService {
  private axios: AxiosInstance;

  constructor() {
    this.axios = axios;
  }

  public getMetrics(): AxiosPromise<any> {
    return axios.get('management/jhimetrics');
  }

  public retrieveThreadDump(): AxiosPromise<any> {
    return axios.get('management/threaddump');
  }
}
